using LevelGenerator.Data;
using UnityEngine;

[CreateAssetMenu(fileName = "RunnerConfig", menuName = "Runner/GeneratorConfig")]
public class RunnerGenConfig : ScriptableObject
{
    [Header("Catalog Reference")]
    [Tooltip("Prefab catalog used for surfaces/occupants lookup.")]
    public PrefabCatalog catalog;

    [Tooltip("Neighbor rules used for WFC + adjacency constraints.")]
    public NeighborRulesConfig weightRules;

    [Header("Track Dimensions")]
    [Tooltip("How many playable lanes exist across the track (X). (Generator adds 2 edge lanes internally.)")]
    public int laneCount = 30;

    [Tooltip("Width of each lane in world units.")]
    public float laneWidth = 10f;

    [Tooltip("Length of a single row/cell in world units (Z).")]
    public float cellLength = 10f;

    [Header("Streaming & Chunking")]
    [Tooltip("Extra rows to keep generated ahead/beyond the active play space.")]
    public int bufferRows = 30;

    [Tooltip("How many rows behind the player we keep alive (cleanup threshold).")]
    public int keepRowsBehind = 20;

    [Tooltip("Number of rows to generate together as a chunk.")]
    public int chunkSize = 10;

    // (kept your tooltip verbatim)
    [Tooltip("Number of rows of existing context to keep, VERY HEAVY.")]
    public int contextRows = 1;

    [Header("Occupant Spawning")]
    [Tooltip("Maximum 'Cost' of occupants per chunk.")]
    public int densityBudget = 60;

    [Tooltip("Chance to attempt occupant spawning per cell (0-1).")]
    [Range(0f, 1f)] public float globalSpawnChance = 0.5f;

    [Header("Noise Placement")]
    [Tooltip("Controls how many world units in Z map to the full [0,1] UV range of the noise.\n" +
             "The larger this is, the longer the world takes to repeat patterns.\n" +
             "Note: U axis maps 1 pixel per lane, so large Z scales will stretch the noise horizontally " +
             "along the track compared to square editor previews unless compensated via noise frequency.")]
    public float worldNoiseScale = 5000f;


    [Header("Golden Path Wave")]
    public bool useWavePath = true;

    [Tooltip("How many lanes wide the safe path is. The path cell itself is always 1 lane; " +
             "setting this to 2 means 1 extra lane on each side is also forced to SafePath before " +
             "the WFC blend starts. Useful for wider tracks or split-lane paths. " +
             "0 or 1 = single-lane path (default).")]
    [Range(1, 6)] public int safePathWidth = 1;

    [Tooltip("How many lanes to either side of the safe path (after width expansion) are " +
             "re-evaluated by the WFC surface blend pass. 0 = disabled. " +
             "1-3 creates a smooth transition zone between the path and the surrounding noise tiles.")]
    [Range(0, 8)] public int safePathBlendRadius = 2;

    [Tooltip("How strongly the wave influences the golden path (0..1).")]
    [Range(0f, 1f)] public float waveStrength = 1f;

    [Tooltip("Max drift from center in lanes (before clamping).")]
    [Range(0f, 150f)] public float waveAmplitudeLanes = 23f;

    [Tooltip("How fast the wave changes per row. Smaller = longer turns.")]
    [Range(0.001f, 0.05f)] public float waveFrequency = 0.0216f;

    [Tooltip("How quickly we chase the target (0..1).")]
    [Range(0.01f, 1f)] public float waveSmoothing = 0.713f;

    [Tooltip("Hard limit: max lanes we can shift per row (turn rate).")]
    [Range(0.05f, 2f)] public float maxLaneChangePerRow = 2f;

    [Tooltip("Keep path away from edges.")]
    [Range(0, 10)] public int edgePadding = 2;

    [Header("Golden Path Rest Straights")]
    [Tooltip("Max number of rows in a straight rest segment.")]
    [Range(2, 300)] public int restAreaMaxLength = 35;

    [Tooltip("Min number of rows in a straight rest segment.")]
    [Range(2, 300)] public int restAreaMinLength = 15;

    [Tooltip("Chance per row to START a rest (0..1). Example: 0.02 ~ roughly once every ~50 rows).")]
    [Range(0f, 1f)] public float restAreaFrequency = 0.05f;

    public void EnsureReady()
    {
        if (worldNoiseScale < cellLength * 2f)
            worldNoiseScale = cellLength * 2f; // Safety clamp to avoid precision death

        if (catalog != null) catalog.RebuildCache();

        if (weightRules != null)
        {
            weightRules.catalog = catalog;
            weightRules.BuildCache();
        }
    }

    private void OnValidate() => EnsureReady();
}